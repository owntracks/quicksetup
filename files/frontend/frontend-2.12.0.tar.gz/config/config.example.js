// Here you can overwite the default configuration values
window.owntracks = window.owntracks || {};
window.owntracks.config = {};
